<?php
$server = "localhost";
$name = "root";
$password = "";
$dbase = "workshop";

$conn= mysqli_connect($server , $name , $password , $dbase);

?>